<?php
class dibs_pw_helpers_cms {   

}
?>
